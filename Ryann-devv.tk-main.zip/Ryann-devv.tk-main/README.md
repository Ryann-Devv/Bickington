# ryann-devvTK

#Server ID: ryannDevvTK
#Server Port: 5003
#Domain: ryann-devv.tk
#Astris Domain: ryann-devvTK.astris.pw
# Server ID: ryannDevvTK
# Server Port: 5003
# Domain: ryann-devv.tk
# Astris Domain: ryann-devvTK.astris.pw
